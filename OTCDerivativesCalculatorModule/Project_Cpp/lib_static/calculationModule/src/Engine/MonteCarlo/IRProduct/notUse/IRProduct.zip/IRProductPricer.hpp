#ifndef quantlib_mc_irproduct_engine_hpp
#define quantlib_mc_irproduct_engine_hpp

#include <vector>
#include <valarray>
#include <ql/timegrid.hpp>
#include <boost/shared_ptr.hpp>
#include "IRCalculation.hpp"
#include <ql/math/array.hpp>

namespace QuantLib {

	class IRProductPricer {
	
		public:
			IRProductPricer(const std::vector<boost::shared_ptr<IRCalculation>>& irCalcList,
							const Array & discounts,
							const TimeGrid& timeGrid);
			
			

			//void calculate(const std::valarray<std::valarray<double>>& paths)
			//{
			//	

			//	for(Size i = pastNum_ ; i < remainCouponSize_ ; ++i)
			//	{
			//		this->irCalcList_[i]->rate(paths);
			//	}
			//}

			void calculate(const MultiPath& paths);

			void reset();

		private:

			void initialize(const TimeGrid& timeGrid);

		//member
		private:
			
			std::vector<boost::shared_ptr<IRCalculation>> irCalcList_;
			Array rateStream_;
			Size remainCouponSize_;
			Size pastNum_;
			Size irCalcNum_;

			Array discounts_;
			TimeGrid timeGrid_;
	};

}

#endif