#ifndef quantlib_my_multi_path_generator_hpp
#define quantlib_my_multi_path_generator_hpp

#include <ql/methods/montecarlo/multipath.hpp>
#include <ql/methods/montecarlo/sample.hpp>
#include <ql/stochasticprocess.hpp>
#include <valarray>

namespace QuantLib {

    //! Generates a multipath from a random number generator.
    /*! RSG is a sample generator which returns a random sequence.
        It must have the minimal interface:
        \code
        RSG {
            Sample<Array> next();
        };
        \endcode

        \ingroup mcarlo

        \test the generated paths are checked against cached results
    */
    template <class GSG>
    class MyMultiPathGenerator {
      public:
        typedef Sample<MultiPath> sample_type;

        MyMultiPathGenerator(std::vector<boost::shared_ptr<StochasticProcess1D>>&,
                           const TimeGrid&,
                           GSG generator,
                           bool brownianBridge = false);

        void next() const;
		boost::shared_ptr<MultiPath> multiPath() const;

		std::valarray<std::valarray<double>> path_;

      private:
        boost::shared_ptr<StochasticProcess> process_;
        GSG generator_;

		
    };


    // template definitions

	template <class GSG>
	MyMultiPathGenerator<GSG>::MyMultiPathGenerator()
	{
	
	}

    template <class GSG>
    MyMultiPathGenerator<GSG>::MyMultiPathGenerator(
                   const boost::shared_ptr<StochasticProcess>& process,
                   const TimeGrid& times,
                   GSG generator,
                   bool brownianBridge)
    : brownianBridge_(brownianBridge), process_(process),
      generator_(generator), next_(boost::shared_ptr<MultiPath>(new MultiPath(process->size(), times)))
	{
		nextPtr_ = next_.get();

        QL_REQUIRE(generator_.dimension() ==
                   process->factors()*(times.size()-1),
                   "dimension (" << generator_.dimension()
                   << ") is not equal to ("
                   << process->factors() << " * " << times.size()-1
                   << ") the number of factors "
                   << "times the number of time steps");
        QL_REQUIRE(times.size() > 1,
                   "no times given");
    }

    template <class GSG>
    inline void MyMultiPathGenerator<GSG>::next() const 
	{
        typedef typename GSG::sample_type sequence_type;
        const sequence_type& sequence_ = generator_.nextSequence();

        Size m = process_->size();
        Size n = process_->factors();

        Array asset = process_->initialValues();
        
		for (Size j=0; j<m; j++)
            path[j].front() = asset[j];

        Array temp(n);

        TimeGrid timeGrid = path[0].timeGrid();
        Time t, dt;
        
		for (Size i = 1; i < path.pathSize(); i++) {
            Size offset = (i-1)*n;
            t = timeGrid[i-1];
            dt = timeGrid.dt(i-1);
            
			std::copy(sequence_.value.begin()+offset,
                            sequence_.value.begin()+offset+n,
                            temp.begin());

            asset = process_->evolve(t, asset, dt, temp,i-1);

            for (Size j=0; j<m; j++)
                path[j][i] = asset[j];
		}
    }

 //   template <class GSG>
 //   inline const typename MyMultiPathGenerator<GSG>::sample_type&
 //   MyMultiPathGenerator<GSG>::antithetic() const 
	//{
	//	QL_FAIL("not impemated antithetic");
 //       return next(true);
 //   }

 //   template <class GSG>
 //   const typename MyMultiPathGenerator<GSG>::sample_type&
 //   MyMultiPathGenerator<GSG>::next(bool antithetic) const 
	//{
 //       QL_FAIL("not impemated antithetic");
	//	return next(true);
 //   }

}
#endif
