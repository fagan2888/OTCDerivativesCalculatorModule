#ifndef quantlib_RateCalculation_hpp
#define quantlib_RateCalculation_hpp

#include <valarray>
#include <ql/time/daycounter.hpp>
#include <src/Engine/MonteCarlo/pricer/event/eventTriggerInfo.hpp>

namespace QuantLib {

	class RateCalculation : public EventTriggerInfo
	{
		public:
			RateCalculation(Real nominal,
			   			  const DayCounter& dayCounter);
						  //const Date& calculationStartDate,
						  //const Date& calculationEndDate,
						  //const Date& paymentDate);

			//virtual ~RateCalculation(){}

		protected:
			DayCounter dayCounter_;
	};
}

#endif