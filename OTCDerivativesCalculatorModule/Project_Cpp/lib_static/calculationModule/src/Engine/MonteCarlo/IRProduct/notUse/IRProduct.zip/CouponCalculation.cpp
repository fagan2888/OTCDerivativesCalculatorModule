#include "RateCalculation.hpp"

namespace QuantLib {

RateCalculation::RateCalculation(Real nominal,
						   const DayCounter& dayCounter)
{

}

}