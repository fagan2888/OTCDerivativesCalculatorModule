#ifndef quantlib_mc_ir_engine_hpp
#define quantlib_mc_ir_engine_hpp

#include <ql/processes/blackscholesprocess.hpp>
#include <ql/processes/stochasticprocessarray.hpp>

#include <ql/exercise.hpp>
#include <ql/indexes/indexmanager.hpp>
#include <fstream>
#include <iostream>
#include <time.h>

#include "IRProductPricer.hpp"
#include "IRProduct.hpp"
#include <ql/methods/montecarlo/mctraits.hpp>

namespace QuantLib {

//------------------------------------------------------------------------------

    class MCIREngine {
		
		typedef MultiVariate<PseudoRandom>::path_generator_type pathGenType;
		typedef MultiVariate<PseudoRandom>::rsg_type rsg_type;

	public:
        MCIREngine( const boost::shared_ptr<IRProduct> irProduct,
					const boost::shared_ptr<StochasticProcess>& process,
					const boost::shared_ptr<YieldTermStructure>& discountCurve,
                    Size simulSamples,
                    BigNatural seed);

        void calculate() const 
		{

			const boost::shared_ptr<IRProductPricer> pp = this->pathPricer();
			const boost::shared_ptr<pathGenType>& pathGen = this->pathGenerator();
			
			std::valarray<std::valarray<double>> paths;

			for(Size j = 1; j <= simulSamples_; j++) 
			{
				pathGen->next() ;
				pp->calculate(paths);
				pp->reset();

				//std::cout << "simul count : " << j << std::endl;
				//sampleAccumulator_.add(pp.calculate(),1.0);
			}

			//std::cout << static_cast<double>((std::clock() - start))/1000 << std::endl;

            //results_.value = this->mcModel_->sampleAccumulator().mean();
            
			//if (RNG::allowsErrorEstimate)
			//{
			//	results_.errorEstimate = this->mcModel_->sampleAccumulator().errorEstimate();
			//}
        }

      protected:
        // McSimulation implementation
        TimeGrid timeGrid() const;
		//TimeGrid wholeTimeGrid() const;

        boost::shared_ptr<pathGenType> pathGenerator() const 
		{

			TimeGrid grid = this->timeGrid();
            Size numAssets = this->process_->size();

			rsg_type rsg = PseudoRandom::make_sequence_generator(numAssets*(grid.size()-1),seed_);

			boost::shared_ptr<pathGenType> genPtr = 
						boost::shared_ptr<pathGenType>(new pathGenType(this->process_,
																	    grid,
																		rsg,false));

			return genPtr;

			//history setting here..

			//index�� Calendar�� product�� Calendar(calculation Date Calendar)�� ���� ������
			//���� index fixing�� ���� Ŭ�������� fixing�ϴµ� �� ����� pathmanager�� indexHistory�� ������ �־ �ű⿡ �����ؼ�, 
			//���� Ŭ���� ���� �����ͼ� fixing ���ѳ�. ����� �����ؼ� ���߿� ��ħ.
			//�׷��Ƿ� path�� ���� ���𰡸� ���� �ʿ�� ����.
			//MultiPath Grid�� product calendar�� grid���� �����.

            
        }

		boost::shared_ptr<IRProductPricer> pathPricer() const;

		protected:
			// data members
			boost::shared_ptr<StochasticProcess> process_;
			boost::shared_ptr<YieldTermStructure> discountCurve_;

			Size simulSamples_;
			BigNatural seed_;

			const boost::shared_ptr<IRProduct> irProduct_;

    };




    // template definitions

    MCIREngine::MCIREngine(const boost::shared_ptr<IRProduct> irProduct,
							const boost::shared_ptr<StochasticProcessArray>& proArrPay,
							const boost::shared_ptr<YieldTermStructure>& discountCurve,
							Size simulSamples,
							BigNatural seed)
    : simulSamples_(simulSamples), seed_(seed) 
	{
		processes_ = boost::shared_ptr<StochasticProcessArray>(
					new StochasticProcessArray(process_vec,corr));

	}

    template <class RNG, class S>
    inline TimeGrid MCIREngine::timeGrid() const {

		const std::vector<Date>& fixings = irProduct_->fixingDates();
        
		Date today = Settings::instance().evaluationDate();

		const Size numberOfFixings = fixings.size();

		DayCounter dayCounter = irProduct_->dayCounter();
        
		std::vector<Time> fixingTimes;

		for (Size i = 0; i < numberOfAdjustedFixings ; ++i) 
		{
			if(today < fixings[i])
				fixingTimes.push_back(dayCounter.yearFraction(today,fixings[i])) ;
		}
        
		return TimeGrid(fixingTimes.begin(), fixingTimes.end());
     
    }
    
    boost::shared_ptr<IRProductPricer> MCIREngine::pathPricer() const 
	{
		const std::vector<Date>& payoffDates = irProduct_->payoffDates();
		const Size numberOfPayoffDates = payoffDates.size();

		Size remainPayoffNum = 0;

		//discount Factor
		Array discounts = Array(numberOfPayoffDates);
		DayCounter dayCounter = irProduct_->dayCounter();
		Date today = Settings::instance().evaluationDate();

		for ( Size i = 0 ; i < payoffDates.size() ; ++i )
		{
			discounts[i] = discountCurve_->discount(dayCounter.yearFraction(today,payoffDates[i]));
		}

        return boost::shared_ptr<IRProductPricer>(
								 new IRProductPricer(irProduct_->irCalcList(),
													 discounts,
													 this->timeGrid());
	}

}

#endif
