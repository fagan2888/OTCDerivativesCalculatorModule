#include "SingleDigitalRangeCoupon.hpp"

namespace QuantLib {

SingleDigitalRangeCoupon::SingleDigitalRangeCoupon(const Date& paymentDate,
									 Real nominal,
									 const DayCounter& dayCounter,
								 	 const Date& accrualStartDate,
									 const Date& accrualEndDate,
									 bool inArrear,
									 std::vector<double> refRateList,
									 std::vector<double> couponRateList,
									 double returnRate)
: IRCalculation(paymentDate,nominal,dayCounter,accrualStartDate,accrualEndDate),
  inArrear_(inArrear),refRateList_(refRateList), couponRateList_(couponRateList),returnRate_(returnRate)
{
	rangeCount_ = refRateList.size();
}


Real SingleDigitalRangeCoupon::rate(const std::valarray<std::valarray<double>>& paths)
{
	double rate = 0.0;
	bool rangeCheck = true;
	double refRate = paths[0][ratePosition_];
				
	for(Size i = 0 ; i < rangeCount_ ;++i)
	{
		if( refRate > refRateList_[i])
		{
			rangeCheck = false;
		}
	}
				
	if ( rangeCheck )
		rate = returnRate_;

	return rate;
			
}

Real SingleDigitalRangeCoupon::rate(const MultiPath& paths)
{
	double rate = 0.0;

	return rate;
}

void SingleDigitalRangeCoupon::initialize(const TimeGrid& timeGrid)
{
	Date today = Settings::instance().evaluationDate();
				
	if(accrualEndDate_ < today )
	{
		this->expired_ = true;
	}

	if(inArrear_)
	{
		double yearFrac = dayCounter_.yearFraction(today,accrualStartDate_);
		ratePosition_ = timeGrid.closestIndex(yearFrac);
		if(timeGrid.closestTime(yearFrac))
		{
			//�ʹ� �ָ� error 
		}
	}
			
}

}