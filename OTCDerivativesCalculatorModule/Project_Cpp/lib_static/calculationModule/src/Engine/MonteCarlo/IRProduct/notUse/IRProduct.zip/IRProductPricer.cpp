#include "IRProductPricer.hpp"

namespace QuantLib 
{

IRProductPricer::IRProductPricer(const std::vector<boost::shared_ptr<IRCalculation>>& irCalcList,
							const Array & discounts,
							const TimeGrid& timeGrid)
: irCalcList_(irCalcList),discounts_(discounts),timeGrid_(timeGrid)
{
	this->irCalcNum_ = irCalcList.size();
	this->pastNum_ = 0;

	for ( Size i=0;i<irCalcNum_;++i)
	{
		bool expired = irCalcList_[i]->isExpired();
		if(expired)
		{
			this->pastNum_ += 1;
		}
	}

	this->initialize(timeGrid);
				
	this->remainCouponSize_ = this->irCalcList_.size();

	rateStream_ = Array(remainCouponSize_,0.0);
}

void IRProductPricer::calculate(const MultiPath& paths)
{
	for(Size i = pastNum_ ; i < remainCouponSize_ ; ++i)
	{
		this->irCalcList_[i]->rate(paths);
	}
}

void IRProductPricer::reset()
{

}

void IRProductPricer::initialize(const TimeGrid& timeGrid)
{
	for( Size i=0;i<irCalcNum_;i++)
	{
		irCalcList_[i]->initialize(timeGrid);
	}
				
}

}