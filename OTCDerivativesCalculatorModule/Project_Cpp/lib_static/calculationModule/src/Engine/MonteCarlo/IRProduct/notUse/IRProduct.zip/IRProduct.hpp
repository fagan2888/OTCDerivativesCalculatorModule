#ifndef quantlib_irproduct_hpp
#define quantlib_irproduct_hpp

#include <ql/time/daycounter.hpp>
#include <vector>
#include "IRCalculation.hpp"

namespace QuantLib {

	class IRProduct {
		public:

			IRProduct(DayCounter dayCounter,
					  const std::vector<boost::shared_ptr<IRCalculation>>& irCalcList);

			std::vector<Date> fixingDates();
			std::vector<Date> payoffDates();
			
			DayCounter dayCounter();
			std::vector<boost::shared_ptr<IRCalculation>> irCalcList();

		private:
			DayCounter dayCounter_;
			Size notional_;
			std::vector<boost::shared_ptr<IRCalculation>> irCalcList_;

	};

}
#endif
