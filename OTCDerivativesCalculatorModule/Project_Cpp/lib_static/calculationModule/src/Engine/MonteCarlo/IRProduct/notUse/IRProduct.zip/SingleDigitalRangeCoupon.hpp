#ifndef quantlib_singledigitalrangecoupon_hpp
#define quantlib_singledigitalrangecoupon_hpp

#include "IRCalculation.hpp"

namespace QuantLib {

	class SingleDigitalRangeCoupon : public IRCalculation 
	{
		public:
			SingleDigitalRangeCoupon(const Date& paymentDate,
									 Real nominal,
									 const DayCounter& dayCounter,
								 	 const Date& accrualStartDate,
									 const Date& accrualEndDate,
									 bool inArrear,
									 std::vector<double> refRateList,
									 std::vector<double> couponRateList,
									 double returnRate);

			Real rate(const std::valarray<std::valarray<double>>& paths);
			Real rate(const MultiPath& paths);

			void initialize(const TimeGrid& timeGrid);

		private:
			bool inArrear_;
			Size ratePosition_;
			Size rangeCount_;
			std::vector<double> refRateList_;
			std::vector<double> couponRateList_;

			//���� �����丵
			double returnRate_;
	};
}

#endif