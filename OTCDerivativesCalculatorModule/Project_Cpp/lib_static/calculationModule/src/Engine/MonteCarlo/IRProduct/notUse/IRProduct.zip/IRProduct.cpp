#include "IRProduct.hpp"

namespace QuantLib 
{

IRProduct::IRProduct(DayCounter dayCounter,
					 const std::vector<boost::shared_ptr<IRCalculation>>& irCalcList)
: dayCounter_(dayCounter), irCalcList_(irCalcList)
{

}

std::vector<Date> IRProduct::fixingDates()
{
	std::vector<Date> fixingDates;
				
	for ( Size i=0;i<irCalcList_.size();i++)
	{
		std::vector<Date> insertDates = irCalcList_[i]->fixingDates();
		fixingDates.insert(fixingDates.end(),insertDates.begin(), insertDates.end());
	}

	return fixingDates;
}

std::vector<Date> IRProduct::payoffDates()
{
	std::vector<Date> payoffDates;
				
	for ( Size i=0;i<irCalcList_.size();i++)
	{
		std::vector<Date> insertDates = irCalcList_[i]->payoffDates();
		payoffDates.insert(payoffDates.end(),insertDates.begin(), insertDates.end());
	}

	return payoffDates;
}

DayCounter IRProduct::dayCounter()
{
	return this->dayCounter_;
}

std::vector<boost::shared_ptr<IRCalculation>> IRProduct::irCalcList()
{
	return this->irCalcList_;
}

}